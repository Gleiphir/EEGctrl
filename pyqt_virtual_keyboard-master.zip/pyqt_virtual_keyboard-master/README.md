# pyqt_virtual_keyboard
PyQt Based Virtual KeyBoard

![alt text](https://github.com/AKOBIBILI/pyqt_virtual_keyboard/blob/master/akobibili_keyboard.png)

This keyboard is design for touch screen applications on crossplatform (Windows, Linux), it was developed for Raspberry Pi with Python 3 for touch screen applications but can also work on windows, it can also be used on different sizes of screen :)

Features :

QWERTY Layout

Resizable based on your screen sizes

PopUp position can be set base on your implementation and screen sizes :)

Implementation :

Open your terminal/Command line, then navigate to pyqt_virtual_keyboard/examples and run then main_window.py

python3 main_window.py

Open for suggestions :)
  
If you see this helpful just treat me some BEER someday :)
